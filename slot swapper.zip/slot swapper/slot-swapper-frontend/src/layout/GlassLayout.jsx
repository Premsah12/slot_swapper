export default function GlassLayout({ title, children }) {
    return (
      <div className="auth-3d-bg">
        {/* Floating shapes */}
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
  
        {/* Main glass container */}
        <div className="glass-card" style={{ width: "800px", maxHeight: "85vh", overflowY: "auto" }}>
          <h1>{title}</h1>
          <div style={{ marginTop: "20px" }}>
            {children}
          </div>
        </div>
      </div>
    );
  }
  