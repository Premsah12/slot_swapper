import GlassLayout from "../layout/GlassLayout";
export default function Requests() {


return (
  <GlassLayout title="Swap Requests">
    <div className="card">
      <p>Incoming and outgoing swap requests will appear here.</p>
    </div>
  </GlassLayout>
);

  
  }
  