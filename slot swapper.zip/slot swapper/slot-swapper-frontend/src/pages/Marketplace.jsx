import { useEffect, useState } from "react";
import API from "../api/api";
import GlassLayout from "../layout/GlassLayout";

export default function Marketplace() {
  const [slots, setSlots] = useState([]);

  // load other users' swappable slots
  async function loadSlots() {
    try {
      const res = await API.get("/swappable-slots");
      setSlots(res.data);
    } catch (err) {
      alert("Failed to load marketplace");
      console.error(err);
    }
  }

  useEffect(() => {
    loadSlots();
  }, []);

  return (
    <GlassLayout title="Marketplace">
      {slots.length === 0 && <p>No swappable slots available</p>}

      {slots.map((slot) => (
        <div className="card" key={slot.id}>
          <b>{slot.title}</b>
          <p>Owner: {slot.User?.name}</p>
          <p>Status: {slot.status}</p>

          <button disabled style={{ opacity: 0.6 }}>
            Request Swap (Next Step)
          </button>
        </div>
      ))}
    </GlassLayout>
  );
}
