import { useState } from "react";
import API from "../api/api";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function login() {
    try {
      const res = await API.post("/login", { email, password });
      localStorage.setItem("token", res.data.token);
      navigate("/dashboard");
    } catch {
      alert("Login failed");
    }
  }

  return (
    <div className="auth-3d-bg">
      {/* Floating shapes */}
      <div className="shape"></div>
      <div className="shape"></div>
      <div className="shape"></div>
      <div className="shape"></div>
  
      {/* Glass login card */}
      <div className="glass-card">
        <h1>SlotSwapper</h1>
        <h2>Smart Time Slot Exchange</h2>
  
        <p>
          SlotSwapper allows users to securely exchange busy calendar time slots
          with others. Mark your slots as swappable, discover available slots,
          and swap schedules with just one click.
        </p>
  
        <input
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />
  
        <input
          type="password"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />
  
        <button onClick={login}>Login</button>
  
        <p style={{ marginTop: "15px", fontSize: "13px" }}>
          New here?{" "}
          <span onClick={() => navigate("/register")}>Create an account</span>
        </p>
      </div>
    </div>
  );
  
  
  
}
