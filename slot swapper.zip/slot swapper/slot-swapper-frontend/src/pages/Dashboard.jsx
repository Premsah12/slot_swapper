import { useEffect, useState } from "react";
import API from "../api/api";
import GlassLayout from "../layout/GlassLayout";

export default function Dashboard() {
  const [events, setEvents] = useState([]);
  const [title, setTitle] = useState("");

  // load my events
  async function loadEvents() {
    const res = await API.get("/events");
    setEvents(res.data);
  }

  // create new event
  async function createEvent() {
    if (!title) {
      alert("Enter event title");
      return;
    }

    await API.post("/events", { title });
    setTitle("");
    loadEvents();
  }

  // make event swappable
  async function makeSwappable(eventId) {
    try {
      await API.put(`/events/${eventId}/swappable`);
      loadEvents();
    } catch (err) {
      alert("Failed to make event swappable");
      console.error(err);
    }
  }

  useEffect(() => {
    loadEvents();
  }, []);

  return (
    <GlassLayout title="My Dashboard">
      <h3>Create Event</h3>

      <input
        placeholder="Event title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <button onClick={createEvent}>Create Event</button>

      <h3 style={{ marginTop: "25px" }}>My Events</h3>

      {events.length === 0 && <p>No events yet</p>}

      {events.map((ev) => (
        <div className="card" key={ev.id}>
          <b>{ev.title}</b>
          <p>Status: {ev.status}</p>

          {ev.status === "BUSY" ? (
            <button
              className="secondary"
              onClick={() => makeSwappable(ev.id)}
            >
              Make Swappable
            </button>
          ) : (
            <span style={{ color: "#00ffcc" }}>✔ Swappable</span>
          )}
        </div>
      ))}
    </GlassLayout>
  );
}
