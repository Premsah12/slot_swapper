const { Sequelize } = require("sequelize");
const path = require("path");

const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: path.join(__dirname, "..", "database.sqlite"),
  logging: false,
});

const User = require("./user")(sequelize);
const Event = require("./event")(sequelize);
const SwapRequest = require("./swapRequest")(sequelize);

// ---------------- ASSOCIATIONS ----------------

// User ↔ Event
User.hasMany(Event, { foreignKey: "userId" });
Event.belongsTo(User, { foreignKey: "userId" });

// User ↔ SwapRequest
User.hasMany(SwapRequest, {
  foreignKey: "requesterId",
  as: "outgoingRequests",
});
User.hasMany(SwapRequest, {
  foreignKey: "responderId",
  as: "incomingRequests",
});

SwapRequest.belongsTo(User, {
  foreignKey: "requesterId",
  as: "requester",
});
SwapRequest.belongsTo(User, {
  foreignKey: "responderId",
  as: "responder",
});

// Event ↔ SwapRequest
Event.hasMany(SwapRequest, {
  foreignKey: "mySlotId",
  as: "mySlotRequests",
});
Event.hasMany(SwapRequest, {
  foreignKey: "theirSlotId",
  as: "theirSlotRequests",
});

module.exports = { sequelize, User, Event, SwapRequest };
