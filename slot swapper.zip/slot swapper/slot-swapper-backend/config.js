require('dotenv').config();
module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'devsecret',
  port: process.env.PORT || 4000
};
