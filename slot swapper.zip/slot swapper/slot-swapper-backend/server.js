require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const { sequelize, User, Event } = require("./models");
const auth = require("./middleware/auth.js");

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || "secret";

/* ---------------- TEST ---------------- */
app.get("/api/ping", (req, res) => {
  res.json({ ok: true });
});

/* ---------------- AUTH ---------------- */

// SIGNUP
app.post("/api/signup", async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: "Missing fields" });
  }

  try {
    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({
      name,
      email,
      passwordHash: hash,
    });

    const token = jwt.sign({ id: user.id }, JWT_SECRET);
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: "Signup failed" });
  }
});

// LOGIN
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(400).json({ error: "Invalid credentials" });

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(400).json({ error: "Invalid credentials" });

    const token = jwt.sign({ id: user.id }, JWT_SECRET);
    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email },
    });
  } catch {
    res.status(500).json({ error: "Login failed" });
  }
});

/* ---------------- EVENTS ---------------- */

// CREATE EVENT (Dashboard button)
app.post("/api/events", auth, async (req, res) => {
  const { title } = req.body;
  if (!title) return res.status(400).json({ error: "Title required" });

  const event = await Event.create({
    title,
    userId: req.user.id,
    status: "BUSY",
  });

  res.json(event);
});

// GET MY EVENTS
app.get("/api/events", auth, async (req, res) => {
  const events = await Event.findAll({
    where: { userId: req.user.id },
  });
  res.json(events);
});

// MAKE EVENT SWAPPABLE
app.put("/api/events/:id/swappable", auth, async (req, res) => {
  const event = await Event.findByPk(req.params.id);
  if (!event || event.userId !== req.user.id) {
    return res.status(404).json({ error: "Event not found" });
  }

  event.status = "SWAPPABLE";
  await event.save();
  res.json(event);
});

// MARKETPLACE – OTHER USERS' SLOTS
app.get("/api/swappable-slots", auth, async (req, res) => {
  const slots = await Event.findAll({
    where: {
      status: "SWAPPABLE",
    },
    include: {
      model: User,
      attributes: ["name"],
    },
  });

  res.json(slots.filter(s => s.userId !== req.user.id));
});

/* ---------------- START ---------------- */

sequelize.sync().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});
